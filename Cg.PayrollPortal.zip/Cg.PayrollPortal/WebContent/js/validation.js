function validateRegistrationForm() {
	if(registerForm.firstName.value==""){
		alert("Enter firstname");
		return false;
	}
	else if(registerForm.firstName.value==""){
		alert("Enter lastname");
		return false;	
	}
	else if(registerForm.emailId.value==""){
		alert("Enter emailId");
		return false;	
	}
	else if(registerForm.department.value==""){
		alert("Enter department");
		return false;	
	}
	else if(registerForm.designation.value==""){
		alert("Enter designation");
		return false;	
	}
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
		alert("Enter yearlyInvestmentUnder80C");
		return false;	
	}
	else if(registerForm.basicSalary.value==""){
		alert("Enter basicSalary");
		return false;	
	}
	else if(registerForm.epf.value==""){
		alert("Enter epf");
		return false;	
	}
	else if(registerForm.companyPf.value==""){
		alert("Enter companyPf");
		return false;	
	}
	else if(registerForm.bankName.value==""){
		alert("Enter bankName");
		return false;	
	}
	else if(registerForm.accountNo.value==""){
		alert("Enter accountNo");
		return false;	
	}
	else if(registerForm.ifscCode.value==""){
		alert("Enter ifscCode");
		return false;	
	}
}